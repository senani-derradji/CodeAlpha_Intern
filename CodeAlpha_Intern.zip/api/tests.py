# run as: python -c "..." or in a python shell
import sys
sys.path.insert(0, '.')
from database.db import SessionLocal
from database.models import User

db = SessionLocal()
user = db.query(User).filter(User.email == "derradjisenani05@gmail.com").first()
if user:
    user.role = "admin"
    db.commit()
    print(f"Done — {user.name} is now admin")
else:
    print("User not found")
db.close()