import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from unittest.mock import MagicMock, patch

import os, sys
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)

from api.url_endpoints import UrlShortenerAPI
from database.db import get_db

app = FastAPI()

url_api = UrlShortenerAPI()

app.include_router(url_api.router)


def override_get_db():

    db = MagicMock()

    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)


url_api.redis.add_short_url = MagicMock()
url_api.redis.check_short_url = MagicMock()
url_api.redis.increment_clicks = MagicMock()
url_api.redis.delete_short_url = MagicMock()


@patch("api.url_endpoints.UrlOperations")
def test_create_short_url_success(mock_url_ops):

    mock_instance = mock_url_ops.return_value

    mock_instance.create_short_url.return_value = {
        "short_url": "http://localhost:8000/abc123",
        "original_url": "https://google.com"
    }

    response = client.post(
        "/shortener",
        json={
            "original_url": "https://google.com"
        }
    )

    assert response.status_code == 200

    data = response.json()

    assert data["short_url"] == (
        "http://localhost:8000/abc123"
    )


@patch("api.url_endpoints.UrlOperations")
def test_create_short_url_failed(mock_url_ops):

    mock_instance = mock_url_ops.return_value

    mock_instance.create_short_url.return_value = None

    response = client.post(
        "/shortener",
        json={
            "original_url": "https://google.com"
        }
    )

    assert response.status_code == 400

    assert response.json() == {
        "detail": "Failed to create short URL"
    }


def test_redirect_from_redis_cache():

    url_api.redis.check_short_url.return_value = (
        "https://google.com"
    )

    response = client.get(
        "/abc123",
        follow_redirects=False
    )

    assert response.status_code == 307

    assert response.headers["location"] == (
        "https://google.com"
    )


@patch("api.url_endpoints.UrlOperations")
def test_redirect_from_database(mock_url_ops):

    url_api.redis.check_short_url.return_value = None

    mock_instance = mock_url_ops.return_value

    mock_instance.domain = "http://localhost:8000"

    mock_instance.change_clicks.return_value = (
        "https://google.com"
    )

    response = client.get(
        "/abc123",
        follow_redirects=False
    )

    assert response.status_code == 307

    assert response.headers["location"] == (
        "https://google.com"
    )


@patch("api.url_endpoints.UrlOperations")
def test_redirect_url_not_found(mock_url_ops):

    url_api.redis.check_short_url.return_value = None

    mock_instance = mock_url_ops.return_value

    mock_instance.domain = "http://localhost:8000"

    mock_instance.change_clicks.return_value = None

    response = client.get(
        "/abc123"
    )

    assert response.status_code == 404

    assert response.json() == {
        "detail": "URL not found"
    }


@patch("api.url_endpoints.UrlOperations")
def test_delete_url_success(mock_url_ops):

    mock_instance = mock_url_ops.return_value

    mock_instance.delete_url.return_value = True

    response = client.delete("/abc123")

    assert response.status_code == 200

    assert response.json() == {
        "message": "URL deleted successfully"
    }


@patch("api.url_endpoints.UrlOperations")
def test_delete_url_failed(mock_url_ops):

    mock_instance = mock_url_ops.return_value

    mock_instance.delete_url.return_value = False

    response = client.delete("/abc123")

    assert response.status_code == 404

    assert response.json() == {
        "detail": "URL not found"
    }